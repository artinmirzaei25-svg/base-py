
name = input("What's Your Name ?")
age = int(input("How old are you ? "))
if age >= 18:
    print("You are old")
else:
    print("You are under 18")

def say_hello(name):
    print("Hello", name)
    print("Welcome")

say_hello(name)

num1 = 10
num2 = 5
print(num1 + num2)
print(num1 - num2)
print(num1 * num2)
print(num1 / num2)
